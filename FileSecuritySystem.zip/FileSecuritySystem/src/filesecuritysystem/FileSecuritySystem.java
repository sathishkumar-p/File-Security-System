/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import com.bluetooth.packages.BluetoothMain;
import com.database.packages.Database;
import com.userProcess.packages.UserValidate;
import java.sql.SQLException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author User
 */
public class FileSecuritySystem extends Application {

    
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("BluetoothLoad.fxml"));
        Scene scene = new Scene(root);
        stage.initStyle(StageStyle.TRANSPARENT);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public  static Database dbObj;
    public  static BluetoothMain bObj;
    public static UserValidate uvObj;
   
    
    public static void main(String[] args)
    {
       
       
        
        launch(args); 
     
          System.out.println(dbObj);
          
             
    }    

    public static void setDbObj(Database dbObj) {
        FileSecuritySystem.dbObj = dbObj;
    }

    public static void setbObj(BluetoothMain bObj) {
        FileSecuritySystem.bObj = bObj;
    }

    public static Database getDbObj() 
    {
        return dbObj;
    }

    public static BluetoothMain getbObj() 
    {
        return bObj;
    }

    public static void setUvObj(UserValidate uvObj) {
        FileSecuritySystem.uvObj = uvObj;
    }
   
          
    }

    


