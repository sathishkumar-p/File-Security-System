/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author User
 */
public class RecoverDeviceController implements Initializable {

    @FXML
    private JFXTextField rcode;
    @FXML
    private JFXButton verify;
    @FXML
    private JFXComboBox<?> newdiv;
    @FXML
    private JFXButton apply;
    ObservableList devicesFound;
    @FXML
    private Label status;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void verifyButtonAction(ActionEvent event) 
    {
        if(DeviceLostController.dlObj.verifyCode(Integer.parseInt(rcode.getText())))
        {
            newdiv.setDisable(false);
            apply.setDisable(false);
            this.devicesFound=FXCollections.observableArrayList(DeviceLostController.dlObj.getMatchedPairedDevicName());
            if(devicesFound.isEmpty())
           {
            status.setText("No Devices Found!!Please Restart the Application");
            newdiv.setDisable(true);
            apply.setDisable(true);
        
           }
        newdiv.setItems(devicesFound);
        }
    }

    @FXML
    private void applyButtonAction(ActionEvent event) throws Exception 
    {
       if( DeviceLostController.dlObj.changeDevice(newdiv.getSelectionModel().getSelectedItem().toString()))
       {
           
           new SceneController("BluetoothLoad.fxml","Loading..",event);
       }
       else
       {
           new SceneController("Error.fxml","Error..",event);
       }
        
        
    }
    
}
