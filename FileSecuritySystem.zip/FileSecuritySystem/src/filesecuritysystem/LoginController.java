/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import com.bluetooth.packages.BluetoothMain;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.validation.RequiredFieldValidator;
import com.userProcess.packages.ExistingUser;
import com.userProcess.packages.UserValidate;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author User
 */
public class LoginController implements Initializable {

    @FXML
    private JFXTextField username;
    @FXML
    private JFXPasswordField password;
    @FXML
    private JFXButton login;
    @FXML
    private Label status;
    @FXML
    private Hyperlink forgotpassword;
    @FXML
    private Hyperlink newuser;
     boolean flagunm=false;
     boolean flagpwd=false;
      public UserValidate uvObj;
      public static ExistingUser euObj;
       
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
        RequiredFieldValidator validator=new RequiredFieldValidator();
        username.getValidators().add(validator);
        validator.setMessage("Username Required");
        username.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) -> {
            //To change body of generated methods, choose Tools | Templates.
            if(newValue.equals(""))
            {
                flagunm=false;
                username.validate();
            }
            else
            {
                flagunm=true;
                
            }
        });
        
        RequiredFieldValidator validatorpwd=new RequiredFieldValidator();
        password.getValidators().add(validatorpwd);
        validatorpwd.setMessage("Password Required");
        password.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) -> {
            //To change body of generated methods, choose Tools | Templates.
            if(newValue.equals(""))
            {
                flagpwd=false;
                password.validate();
            }
            else
            {
                flagpwd=true;
                
            }
        });
        
        uvObj=FileSecuritySystem.bObj.getUserValidate();
        
    }    

    @FXML
    private void handleLoginAction(ActionEvent event) 
    {
        if(flagunm&&flagpwd)
        {
            if(uvObj.validate(username.getText(), password.getText()))
            {
                /*Next Page*/
                euObj=uvObj.getExisitingUserObject();
                try 
                {
                    new SceneController("Index.fxml","Index Page",event);
                } catch (Exception ex) 
                {
                    Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else
            {
                status.setText("UserName/Password Incorrect");
            }
        }
        else
        {
            status.setText("Enter Valid UserName/Password");
        }
    }

    @FXML
    private void handleForgotPasswordAction(ActionEvent event) throws Exception 
    {
        uvObj.validate("forgot","forgot");
        new SceneController("ResetPassword.fxml","Reset Page",event);
    }
   @FXML
    private void handleNewUserAction(ActionEvent event) 
    {
        try 
        {
            new SceneController("NewUser.fxml","New User Page",event);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
   
}
