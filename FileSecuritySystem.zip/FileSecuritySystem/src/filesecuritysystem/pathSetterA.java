/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author User
 */
public class pathSetterA 
{
     private final SimpleStringProperty pathName;
        private final SimpleStringProperty fileName;
        

        public String getPathName() {
            return pathName.get();
        }

   
    

        public String getFileName() {
            return fileName.get();
        }

        public pathSetterA(String pathName, String fileName) {
            this.pathName = new SimpleStringProperty(pathName);
            this.fileName = new SimpleStringProperty(fileName);
           
        }
    
    
}
