/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author User
 */
public class SceneController 
{
    public SceneController(String pageToLoad,String title, ActionEvent event) throws Exception
	{
		Parent root=FXMLLoader.load(getClass().getResource("/filesecuritysystem/"+pageToLoad));
		Scene scene = new Scene(root);
		Stage primaryStage= new Stage();
		primaryStage.setTitle(title);
		primaryStage.setScene(scene);
                if(pageToLoad.equals("BluetoothLoad.fxml"))
                {
                 primaryStage.initStyle(StageStyle.TRANSPARENT);
                }
                else
                {
                    primaryStage.setResizable(false);
                }
                            
		primaryStage.show();
		((Node)(event.getSource())).getScene().getWindow().hide();
		
	}
    
}
