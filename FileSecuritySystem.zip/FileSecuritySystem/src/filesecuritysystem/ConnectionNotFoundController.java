/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author User
 */
public class ConnectionNotFoundController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML
    private JFXButton refresh;
    
    @FXML
    private JFXButton newuser;
    @FXML
    private JFXButton lost;
    
    @FXML
    private void handleRefreshButtonAction(ActionEvent event)
    {
        try 
        {
            new SceneController("BluetoothLoad.fxml","Load...",event);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    @FXML
    private void handleNewUserButtonAction(ActionEvent event)
    {
        try 
        {
            new SceneController("NewUser.fxml","New User Page",event);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleLostDeviceButtonAction(ActionEvent event) throws Exception 
    {
        new SceneController("DeviceLost.fxml","Device Lost",event);
    }
    
}
