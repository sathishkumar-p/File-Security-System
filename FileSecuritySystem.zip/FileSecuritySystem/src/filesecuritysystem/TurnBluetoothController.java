/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author User
 */
public class TurnBluetoothController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
     JFXButton restart;
    
     @FXML
    public void RestartButtonAction(ActionEvent event)
    {
        try 
        {
            new SceneController("BluetoothLoad.fxml","Connection Page",event);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
    }    
    
}
