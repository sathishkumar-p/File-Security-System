/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author User
 */
public class ErrorPageController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private void handleDoneButtonAction(ActionEvent event) throws Exception
    {
        new SceneController("BluetoothLoad.fxml","Load...",event);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
    }    
    
}
