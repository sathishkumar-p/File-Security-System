/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import com.bluetooth.packages.DeviceLost;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author User
 */
public class DeviceLostController implements Initializable {

    @FXML
    private JFXTextField username;
    @FXML
    private JFXTextField email;
    @FXML
    private JFXPasswordField password;
    @FXML
    private JFXButton validate;
    public static DeviceLost dlObj;
    @FXML
    private JFXButton REFRESH;
    @FXML
    private Label status;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
       dlObj= new DeviceLost(FileSecuritySystem.getDbObj()); 
        
    }    

    @FXML
    private void deviceRecoveryAction(ActionEvent event) throws Exception 
    {
        if(dlObj.netIsAvailable())
        {
            if(!username.getText().equals("")||!password.getText().equals("")||!email.getText().equals(""))
            {
                if(dlObj.verifyUser(username.getText(), password.getText(), email.getText()))
                {
                    new SceneController("RecoverDevice.fxml","Recover Device",event);
                }
                else
                {
                    status.setText("Invalid Details");
                    username.setText("");
                    password.setText("");
                    email.setText("");
                }
            }
            else
            {
                status.setText("Invalid Details");
                    username.setText("");
                    password.setText("");
                    email.setText("");
                
            }
            
            
        }
        else
        {
            //Net UnAvailable
            status.setText("Internet Unavailable: Connect To Internet and Press REFRESH");
        }
    }

    @FXML
    private void netRefreshAction(ActionEvent event) throws Exception 
    {
        new SceneController("DeviceLost.fxml","Recover Device",event);
    }
    
}
