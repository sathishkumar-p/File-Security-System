/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import com.jfoenix.controls.JFXTextField;
import com.jfoenix.validation.RequiredFieldValidator;
import com.userProcess.packages.ForgotPassword;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author User
 */
public class ResetPasswordController implements Initializable {

    /**
     * Initializes the controller class.
     */
     @FXML
    private JFXTextField username;
    
    @FXML
    private JFXTextField email;
    
    @FXML
    private Label status;
    
    boolean flagunm=false;
    boolean flageid=false;
    
    public static ForgotPassword fpObj;
    
    
    @FXML
    private void handleResetAction(ActionEvent event) throws Exception
    {
      if(fpObj.netIsAvailable())
      {
          if(fpObj.emailValidate(email.getText()))
          {
              new SceneController("VerifyResetCode.fxml","Verify Code",event);
          }
          else
          {
              status.setText("Enter Valid Email ID");
              email.setText("");
          }
          
      }
      else
      {
          status.setText("Connect To Internet and restart Application");
          
      }
        
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
       
        
        RequiredFieldValidator validatoreid=new RequiredFieldValidator();
        email.getValidators().add(validatoreid);
        validatoreid.setMessage("Email ID Required");
        email.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) -> {
            //To change body of generated methods, choose Tools | Templates.
            if(!newValue)
            {
                flageid=false;
                email.validate();
            }
            else
            {
                flageid=true;
                
            }
        });
        
        fpObj=FileSecuritySystem.bObj.getUserValidate().getFP();
    }    
    
}
