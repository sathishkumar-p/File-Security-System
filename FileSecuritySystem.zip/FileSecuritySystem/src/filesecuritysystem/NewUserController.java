/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.validation.RequiredFieldValidator;
import com.userProcess.packages.NewUser;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author User
 */
public class NewUserController implements Initializable {

    @FXML
    private JFXComboBox<?> bluetoothdevice;
    @FXML
    private JFXTextField username;
    @FXML
    private JFXTextField email;
    @FXML
    private JFXPasswordField password;
    @FXML
    private JFXPasswordField confirmpwd;
    @FXML
    private JFXButton done;
    @FXML
    private Label status;
    @FXML
    private Hyperlink restart;
    
   
    boolean flagunm=false;
    boolean flagpwd=false;
    boolean flageid=false;
    NewUser nuObj;
    ObservableList devicesFound;

    /**
     * Initializes the controller class.
     */
    
    @FXML
    private void handleDoneButtonAction(ActionEvent event) throws Exception
    {
        
        if(flagunm&&flagpwd&&flageid)
        {
           Pattern p =Pattern.compile("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$");
            Matcher m = p.matcher(email.getText());
                          
            if(!m.matches())
            {
            email.setText("");
            status.setText("Email id is not vaild");
            }
            else if(!password.getText().equals(confirmpwd.getText()))
        {
            confirmpwd.setText("");
            status.setText("Password Dosnt Match!!");
            
        }
        else if(bluetoothdevice.getSelectionModel().getSelectedItem().toString().equals(""))
        {
            status.setText("Select Valid Bluetooth Device");
        }
        else 
        {
            if(nuObj.addUser(bluetoothdevice.getSelectionModel().getSelectedItem().toString(), username.getText(),password.getText(),email.getText()))
            {
              System.out.println("Added");
              new SceneController("BluetoothLoad.fxml","Loading...",event);  
            }
            else
            {
                System.out.println("error");
                System.out.println(flagunm+""+flageid+flagpwd);
                /*Alert Box*/
            }
            
        }
        
        }
        else
        {
            System.out.println("Error");
        }
        
        /*else if("cant find device")
        {
        restart.fire();
        }
        */
        
    }
    
    @FXML
    private void handleRestartAction(ActionEvent event) throws Exception
    {
        new SceneController("BluetoothLoad.fxml","Loading...",event); 
    
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
        RequiredFieldValidator validator=new RequiredFieldValidator();
        username.getValidators().add(validator);
        validator.setMessage("Username Required");
        username.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) -> {
            //To change body of generated methods, choose Tools | Templates.
            if(newValue.equals(""))
            {
                flagunm=false;
                username.validate();
            }
            else
            {
                flagunm=true;
                System.out.println("flagunm"+flagunm);
            }
        });
        
        RequiredFieldValidator validators;
        validators = new RequiredFieldValidator();
        confirmpwd.getValidators().add(validators);
        validators.setMessage("Retype Password");
        confirmpwd.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) -> {
            //To change body of generated methods, choose Tools | Templates.
            if(newValue.equals(""))
            {
                
                confirmpwd.validate();
            }
           
        });
         RequiredFieldValidator validatoreid=new RequiredFieldValidator();
        email.getValidators().add(validatoreid);
        validatoreid.setMessage("Enter Valid Email ID");
        email.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) -> {
            //To change body of generated methods, choose Tools | Templates.
            
                   
            if(newValue.equals(""))
            {
                flageid=false;
                email.validate();
            }
            else
            {
                flageid=true;
                 System.out.println("flageid"+flageid);
            }
        });
        
         RequiredFieldValidator validatorpwd=new RequiredFieldValidator();
        password.getValidators().add(validatorpwd);
        validatorpwd.setMessage("Password Required");
        password.focusedProperty().addListener((ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) -> {
            //To change body of generated methods, choose Tools | Templates.
            if(newValue.equals(""))
            {
                flagpwd=false;
                password.validate();
            }
            else
            {
                flagpwd=true;
                                 System.out.println("flagpwd"+flagpwd);

            }
        });
        
        nuObj=new NewUser(FileSecuritySystem.dbObj);
        this.devicesFound=FXCollections.observableArrayList(this.nuObj.getMatchedPairedDevicName());
        if(devicesFound.isEmpty())
        {
            status.setText("No Devices Found!!Please Restart the Application");
            bluetoothdevice.setDisable(true);
        
        }
        bluetoothdevice.setItems(devicesFound);
       
    }    
    
}
