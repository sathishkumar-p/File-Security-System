/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author User
 */
public class VerifyResetCodeController implements Initializable {

    @FXML
    private JFXTextField rcode;
    @FXML
    private JFXButton verify;
    @FXML
    private JFXPasswordField npwd;
    @FXML
    private JFXPasswordField cpwd;
    @FXML
    private JFXButton apply;
    @FXML
    private Label status;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
    }    

    @FXML
    private void onVerifyAction(ActionEvent event) 
    {
        if(ResetPasswordController.fpObj.screteCodeValidate(Integer.parseInt(rcode.getText())))
        {
            npwd.setDisable(false);
            cpwd.setDisable(false);
            rcode.setDisable(true);
            verify.setDisable(true);
            status.setText("Enter New Password");
        }
        else
        {
            status.setText("Enter Valid Code");
            rcode.setText("");
        }
    }

    @FXML
    private void applyButtonAction(ActionEvent event) throws Exception 
    {
        if(!npwd.getText().equals(""))
        {
            if(npwd.getText().equals(cpwd.getText()))
            {
                if(ResetPasswordController.fpObj.passwordRestting(npwd.getText()))
                {
                    new SceneController("BluetoothLoad.fxml","Loading...",event);
                }
                else
                {
                    new SceneController("ErrorPage.fxml","ErrorPage",event);
                }
                
            }
        }
        else
        {
            status.setText("Enter Valid Password");
            npwd.setText("");
            cpwd.setText("");
        }
        
        
    }
    
}
