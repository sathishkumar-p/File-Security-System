/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import com.bluetooth.packages.BluetoothMain;
import com.database.packages.Database;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDialog;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author User
 */
public class BluetoothLoadController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Label displayLabel;
    
    @FXML
     JFXButton error;
    
    @FXML
     JFXButton loginpage;
    
    @FXML
     JFXButton connectionnf;
    
    @FXML
     JFXButton turnbluetooth;
     Database dbObj;
     BluetoothMain bObj;    
    @FXML
    public void errorButtonAction(ActionEvent event)
    {
        try 
        {
            new SceneController("ErrorPage.fxml","Error Page",event);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    @FXML
    public void connectionNFButtonAction(ActionEvent event)
    {
        try 
        {
            new SceneController("ConnectionNotFound.fxml","Connection Error Page",event);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    @FXML
    public void loginButtonAction(ActionEvent event)
    {
        try 
        {
            new SceneController("Login.fxml","Login Page",event);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    @FXML
    public void turnbluetoothButtonAction(ActionEvent event)
    {
        try 
        {
            new SceneController("turnBluetooth.fxml","Turn Bluetooth Onn Page",event);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
     
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
        
        displayLabel.setOnMouseEntered((MouseEvent e) -> {
            displayLabel.setScaleX(1.5);
            displayLabel.setScaleY(1.5);
                     
        });
        
        displayLabel.setOnMouseExited((MouseEvent e) -> {
            displayLabel.setScaleX(1);
            displayLabel.setScaleY(1);
            
        });
        try {
            dbObj=new Database();
            bObj=new BluetoothMain(dbObj);
            FileSecuritySystem.setDbObj(dbObj);
            FileSecuritySystem.setbObj(bObj);
                                  
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       /* ExecutorService executor= Executors.newCachedThreadPool();
        Future<Integer> future=executor.submit(new Callable<Integer>(){
            @Override
            public Integer call() throws Exception 
            {
                  try
                {
                    if(bObj.isLocalDevicePowerOn())
                    {
                        if(bObj.searchBluetoothDevice())
                        {
                            // loginpage.fire();
                            return 1;
                                    
                        }
                        else
                        {
                                   // connectionnf.fire();
                            return 2;
                               
                            
                        }
                        
                    }
                    else
                    {
                        
                                //connectionnf.fire();
                        return 2;
                           
                    }
                    
                }
                
                catch(Exception ex)
                {
                    // error.fire();
                   
                            //error.fire();
                    return 3;
                       
                }  //To change body of generated methods, choose Tools | Templates.
 
                
               
                
            }
            
        });
        executor.shutdown();
        
        try {
            int value=future.get();
            if(value==1)
            {
                loginpage.fire();
            }
            else if(value==2)
            {
              connectionnf.fire();
            }
            else
            {
                error.fire();
            }
            */
           new Thread()
            {
            @Override
            public void run() {
            
            if (dbObj==null) {
            System.out.println("gof");
            } /*Proceed to error page //error.fire();*/
            try
            {
            if(bObj.isLocalDevicePowerOn())
            {
            if(bObj.searchBluetoothDevice())
            {
            
            
            Platform.runLater(new Runnable(){
            public void run()
            {
            
            
            loginpage.fire();
            
            
            }});
            }
            else
            {
            /*ConnectionNotFound*/
            //
            Platform.runLater(new Runnable(){
            public void run()
            {
            connectionnf.fire();
            }});
            
            }
            
            }
            else
            {
            /*ConnectionNotFound*/
            //connectionnf.fire();
            Platform.runLater(new Runnable(){
            public void run()
            {
              turnbluetooth.fire();
            }});
            }
            
            }
            
            catch(Exception ex)
            {
            // error.fire();
            Platform.runLater(new Runnable(){
            public void run()
            {
            error.fire();
            }});
            }  //To change body of generated methods, choose Tools | Templates.
            
            }
            
            }.start(); 
     /*   } catch (InterruptedException ex) {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ExecutionException ex) {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        }*/
            
        
      
    
}
}
