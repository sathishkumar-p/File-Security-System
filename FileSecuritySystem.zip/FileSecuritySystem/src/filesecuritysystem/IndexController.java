/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filesecuritysystem;

import com.bluetooth.packages.ServicesSearch;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTabPane;
import com.jfoenix.controls.JFXTextField;
import com.userProcess.packages.ExistingUser;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.application.Platform;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;

/**
 * FXML Controller class
 *
 * @author User
 */
public class IndexController implements Initializable 
{
    @FXML
    private TableView<pathSetter> table;
    @FXML
    private TableColumn<pathSetter,String> fname;
    @FXML
    private TableColumn<pathSetter,String> fpath;
    @FXML
    private TableView<pathSetterA> table1;
    @FXML
    private TableColumn<pathSetterA,String> fname1;
    @FXML
    private TableColumn<pathSetterA,String> fpath1;
     @FXML
     private JFXButton error;
    final ObservableList<pathSetter> pathnm=FXCollections.observableArrayList();
    final ObservableList<pathSetterA> apppathnm=FXCollections.observableArrayList();
    ObservableList devicesFound;
     ExistingUser euObj;
    @FXML
    private JFXTabPane tabPane;
    @FXML
    private Tab t;
    @FXML
    private JFXButton addfiles;
    @FXML
    private JFXButton addfolders;
    @FXML
    private JFXButton removeBtnMain;
    @FXML
    private JFXButton addfiles1;
    @FXML
    private JFXButton removeBtn1Main;
    @FXML
    private JFXTextField unm;
    @FXML
    private JFXTextField email;
    @FXML
    private JFXPasswordField password;
    @FXML
    private JFXTextField currentdevice;
    @FXML
    private JFXPasswordField newpwd;
    @FXML
    private JFXPasswordField confrmpwd;
    @FXML
    private JFXButton changediv;
    @FXML
    private JFXButton changepwd;
    @FXML
    private JFXComboBox<?> selectdevice;
    @FXML
    private Label status;
    @FXML
    private JFXButton apply;
    @FXML
    private JFXButton setpwd;
    @FXML
    private JFXButton cancel;
    boolean flagCD=false;
    boolean flagCP=false;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
         euObj=LoginController.euObj;
          for (String filePath : this.euObj.getFilePaths()) 
        {
            System.out.println(filePath);
            pathnm.add(new pathSetter(filePath,generateFnm(filePath)));                //System.out.println("Added");
        }
          fname.setCellValueFactory(new PropertyValueFactory<pathSetter,String>("FileName"));
       fpath.setCellValueFactory(new PropertyValueFactory<pathSetter,String>("PathName"));
       
      
       table.setItems(pathnm); 
       for (String filePath : this.euObj.getApplicationPaths()) 
        {
            System.out.println(filePath);
            apppathnm.add(new pathSetterA(filePath,generateFnm(filePath)));                //System.out.println("Added");
        }
        fname1.setCellValueFactory(new PropertyValueFactory<pathSetterA,String>("FileName"));
       fpath1.setCellValueFactory(new PropertyValueFactory<pathSetterA,String>("PathName"));
       
       table1.setItems(apppathnm); 
       currentdevice.setText(euObj.getUserDeviceName());
       unm.setText(euObj.getUserName());
       password.setText(euObj.getPassword());
       email.setText(euObj.getEmail());
       
        
       
        new Thread()
            {
            @Override
            public void run() {
       try {

           boolean flag=false;

     for (int k = 0; k == 0;) {

      ServicesSearch ss = new ServicesSearch();
      Map < String, List < String >> mapReturnResult = new HashMap < String, List < String >> ();
      mapReturnResult = ss.getBluetoothDevices();
        flag=false;
      for (Map.Entry < String, List < String >> entry: mapReturnResult.entrySet())
      {
            
       if (euObj.getUserDeviceAddress().equals(entry.getValue().get(1).toString())) {
        if (entry.getValue().size() > 2 && entry.getValue().get(2) != null) {

         System.out.println("Connected");
             flag=true;   
        }
        
        
       }
     


      }
        if(!flag)
       {
         k = 2;
        
         System.out.println("Device disconnected");//error close the application
         Platform.runLater(new Runnable(){
            public void run()
            {
            error.fire();
            }});
          break;
       }

     }
    
 
  } catch (Exception e) {
   System.out.println("Error in Bluetooth Main asyncBluetoothCheck" + e);
  
  }
       }
            
            }.start(); 
       
      
    }    

    @FXML
    private void addFileAction(ActionEvent event) 
    {
        FileChooser fc=new FileChooser();
        fc.setTitle("Select Your Files");
        fc.setInitialDirectory(new File("C:\\Users\\User\\Desktop"));
        fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("All Files","*.docx","*.doc","*.txt","*.rtf","*.odt","*.mp3","*.wav","*.aac","*.wms","*.m4a","*.avi","*.mp4","*.mov","*.flv","*.mpg","*.mkv","*.pdf","*.xls","*.csv","*.ini","*.html","*.zip","*.rar","*.7z","*.tar","*.gz"));
        List<File> selectedFiles;
        ArrayList<String> filesToUpload=new ArrayList<>();
        selectedFiles = fc.showOpenMultipleDialog(null);
        if(selectedFiles!=null)
        {
            for(int i=0;i<selectedFiles.size();i++)
            { 
                //filefolderView.getItems().add(selectedFiles.get(i).getAbsolutePath());
                pathnm.add(new pathSetter(selectedFiles.get(i).getAbsolutePath(),generateFnm(selectedFiles.get(i).getAbsolutePath())));
               //System.out.println("Error");
              /* fname.setCellValueFactory(new PropertyValueFactory<pathSetter,String>("fname"));
               fpath.setCellValueFactory(new PropertyValueFactory<pathSetter,String>("fpath"));
               table.setItems(pathnm);*/
               filesToUpload.add(selectedFiles.get(i).getAbsolutePath());
                
            }
            euObj.addFile(filesToUpload);
            System.out.println("Error1");
        }
            else
        {
            System.out.println("File Not Selected");
        }
    }

    @FXML
    private void addFolderAction(ActionEvent event) {
        DirectoryChooser chooser = new DirectoryChooser();
       chooser.setTitle("Select Your Folder");
       chooser.setInitialDirectory(new File("C:\\Users\\User\\Desktop"));
       File selectedDirectory = chooser.showDialog(null);
       if(selectedDirectory!=null)
        {
            
            pathnm.add(new pathSetter(selectedDirectory.getAbsolutePath(),generateFnm(selectedDirectory.getAbsolutePath())));
            ArrayList<String> filesToUpload=new ArrayList<>();
            filesToUpload.add(selectedDirectory.getAbsolutePath());
            euObj.addFile(filesToUpload);
        }
            else
        {
            System.out.println("Directory Not Selected");
        }
    }

    @FXML
    private void removeBtnMainAction(ActionEvent event) 
    {
        euObj.removeFile(table.getSelectionModel().getSelectedItem().getPathName());
        pathnm.remove(table.getSelectionModel().getSelectedItem());
        
    }
     @FXML
    private void removeBtn1MainAction(ActionEvent event)
    {
        euObj.unlockApplication(table1.getSelectionModel().getSelectedItem().getPathName());
        apppathnm.remove(table1.getSelectionModel().getSelectedItem());
    
    }
    @FXML
    public void connectionNFButtonAction(ActionEvent event)
    {
        try 
        {
            new SceneController("Error.fxml","Error Page",event);
        } 
        catch (Exception ex) 
        {
            Logger.getLogger(BluetoothLoadController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    @FXML
    private void addApplicationAction(ActionEvent event) 
    {
        FileChooser fc=new FileChooser();
        fc.setTitle("Select Your Application");
        fc.setInitialDirectory(new File("C:\\Users\\User\\Desktop"));
        fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Application Files","*.exe"));
        File selectedDirectory;
        selectedDirectory = fc.showOpenDialog(null);
        if(selectedDirectory!=null)
        {
            apppathnm.add(new pathSetterA(selectedDirectory.getAbsolutePath(),generateFnm(selectedDirectory.getAbsolutePath())));
            euObj.lockApplication( selectedDirectory.getAbsolutePath());
        }
            else
        {
            System.out.println("Application Not Selected");
        }
    }
    
     public String generateFnm(String filepath)
    {
        return filepath.substring( filepath.lastIndexOf("\\")+1);
    }

    @FXML
    private void changeDivAction(ActionEvent event)
    {
        flagCD=true;
        
        this.devicesFound=FXCollections.observableArrayList(this.euObj.getMatchedPairedDevicName());
        if(devicesFound.isEmpty())
        {
            status.setText("Pair a Device and Restart The Application for Changing Connection");
            
        }
        else
        {
            selectdevice.setDisable(false);
            
        }
        selectdevice.setItems(devicesFound);
        
    }

    @FXML
    private void changePwdAction(ActionEvent event) 
    {
        password.setDisable(false);
         password.setText("");
        status.setText("Enter Your Current Password and Press SET NEW PASSWORD!");
        changepwd.setDisable(true);
        setpwd.setDisable(false);
        
       
    }

    @FXML
    private void applyAction(ActionEvent event) throws Exception 
    {
        
           Pattern p =Pattern.compile("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$");
            Matcher m = p.matcher(email.getText());
                          
            if(!m.matches())
            {
            email.setText("");
            status.setText("Enter Valid Mail ID");
            }
            else if(flagCP)
            {
                if(newpwd.getText().equals(""))
                {
                    status.setText("Enter Valid Password!!");
                    newpwd.setText("");
                    confrmpwd.setText("");
                }
                else if(!newpwd.getText().equals(confrmpwd.getText()))
                {
                    status.setText("Password Dosnt Match!!");
                    confrmpwd.setText("");
                }
                else
                {
                    password.setText(newpwd.getText());
                    flagCP=false;
                }
                       
            }
           else if(flagCD)
           {
               if(selectdevice.getSelectionModel().getSelectedItem().toString().equals(""))
               {
                   status.setText("Select Valid Bluetooth Device");
               }
               else
               {
                   currentdevice.setText(selectdevice.getSelectionModel().getSelectedItem().toString());
                   flagCD=false;
               }
           }
           else if(unm.getText().equals(""))
           {
               status.setText("Enter Valid User Name"); 
               unm.setText("");
           }
           else 
           {
               System.out.println(currentdevice.getText()+unm.getText()+password.getText()+email.getText());
            if(euObj.editProfile(currentdevice.getText(), unm.getText(), password.getText(), email.getText()))
            {
              System.out.println("Added");
              new SceneController("Restart.fxml","restart",event);
                FileSecuritySystem.main(null);
            }
            else
            {
                System.out.println("error");
                 new SceneController("ErrorPage.fxml","Error...",event);
                
                /*Alert Box*/
            }
            
          }
    }

    @FXML
    private void setAction(ActionEvent event) 
    {
        if(password.getText().equals(this.euObj.getPassword()))
        {
            status.setText("Enter New Password");
            password.setDisable(true);
             newpwd.setDisable(false);
              confrmpwd.setDisable(false);
              flagCP=true;
        }
        else{
            password.setText("");
            status.setText("Incorrect Password");
            
        }
    }

    @FXML
    private void cancelAction(ActionEvent event) throws Exception
    {
        new SceneController("Index.fxml","Index Page",event);
    }
    
}
