/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cryptosystem.packages;


import java.io.IOException;

public class ApplicationLockUnlock {

   
    public void Lock(String path)
    {
    	 Runtime runtime=Runtime.getRuntime();
         try {
             Process process= runtime.exec("cmd.exe /c start attrib +s +h +a "+path+"");
             
             
         } catch (IOException e) {
             // TODO Auto-generated catch block
             e.printStackTrace();
         }
    	
    }
    
   public void unLock(String path)
    {
    	 Runtime runtime=Runtime.getRuntime();
         try {
             //Process process= runtime.exec("cmd.exe /c  start cacls D:\\test.txt /e /d %username%:f");
        	 Process process= runtime.exec("cmd.exe /c start attrib -s -h -a "+path+"");
           
         } catch (IOException e) {
             // TODO Auto-generated catch block
             e.printStackTrace();
         }
    }
}

