/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cryptosystem.packages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.io.FileUtils;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;
/**
 *
 * @author kevin
 */
public class FileEncryption {
    
    String password;
    ArrayList<String> paths;
    Runtime runtime;
    
     public FileEncryption(String password,ArrayList<String> paths) throws ZipException, IOException{
       this.password=password;
       this.paths=paths;
       runtime=Runtime.getRuntime();
       for(String path:paths){
           encryptFile(path);
       }
        
    }
     private void encryptFile(String filePaths) throws ZipException, IOException {
		
		try{
                String filePath=filePaths+".zip";
		Path path = Paths.get(filePath+".enc");
		ZipFile zipFile = new ZipFile(filePath);
		
                
		ZipParameters parameters = new ZipParameters();
		parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
		
		// Set the compression level
		parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
		parameters.setEncryptFiles(true);
		parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
		parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
		parameters.setPassword(password);
		// Add folder to the zip file
                if(filePaths.indexOf(".")>=0)
                {
                File file=new File(filePaths);
                zipFile.addFile(file, parameters);
		FileUtils.forceDelete(new File(file.toString()));
                }
                else{
                    String folderToAdd = filePaths;
                    zipFile.addFolder(folderToAdd, parameters);
                    FileUtils.forceDelete(new File(folderToAdd));
                }
		
                
		encrypt(filePath);
		//Process process= runtime.exec("cmd.exe /c start attrib +s +h +a "+filePath+".enc");
	        FileUtils.forceDelete(new File(filePath));
		System.out.print("Done encryption");
                }
                 catch (IOException | ZipException e) {
	           System.out.println("Error in ecryption encryptFile(String filePaths) " + e);
	        }
	}
     private void encrypt(String filePath){
          /*
	         * Takes filePath and password as argument and creates a encrypted file by name filePath.enc
	         */
	        try
	        {
                    try (FileInputStream fis = new FileInputStream(filePath) // file to be encrypted
                    ; FileOutputStream fos = new FileOutputStream(filePath+".enc") // encrtpted file
                    ) {
                        byte[] keyBytes = getKey(); // get md5 hash of the password
                        SecretKeySpec key = new SecretKeySpec(keyBytes,"AES"); // secret key for aes
                        Cipher cipher = Cipher.getInstance("AES"); // get cipher
                        cipher.init(Cipher.ENCRYPT_MODE,key); // init cipher
                        try (CipherInputStream cis = new CipherInputStream(fis,cipher) // get chiper input stream, to read teh file
                        ) {
                            byte buf[] = new byte[1024];
                            int len;
                            while( (len = cis.read(buf,0,buf.length)) != -1) // read till end
                            {
                                fos.write(buf,0,len); // write out to encrypted file
                            }
                        }
                    } // encrtpted file
                    // encrtpted file // encrtpted file
                    // encrtpted file
                    	        }
	        catch (IOException | InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException e) // catch all exceptions #TODO proper cleanup
	        {
	            System.out.println("Error in ecryption encrypt(String filePath) " + e);
	        }
     }
     private  byte[] getKey()
	    {
	        /*
	         * Takes a string as input and returns its MD5 in byte[]
	         */
	        try
	        {
	            MessageDigest md5 = MessageDigest.getInstance("MD5"); // get the MD5 instance
	            return md5.digest(password.getBytes()); // get md5 of key ( byte[] )
	        }
 	        catch(NoSuchAlgorithmException e)
	        {
	              System.out.println("Error encryption getKey()" + e);                    
	        }
	            return new byte[1];
	    }
}
