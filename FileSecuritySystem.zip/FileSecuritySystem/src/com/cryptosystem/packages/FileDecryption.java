/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cryptosystem.packages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.io.FileUtils;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
/**
 *
 * @author kevin
 */
public class FileDecryption {
    
     String password;
     ArrayList<String> paths;
    Runtime runtime;
     public FileDecryption(String password,ArrayList<String> paths) throws ZipException, IOException{
       this.password=password;
       this.paths=paths;
       runtime=Runtime.getRuntime();
       for(String path:paths){
           decryptFile(path+".zip");
       }
        
    }
    
    private void decryptFile(String filePath) throws ZipException, IOException{
                
		//Process process= runtime.exec("cmd.exe /c start attrib -s -h -a "+filePath+".enc");
                Path path = Paths.get(filePath+".enc");
		//Files.setAttribute(path, "dos:hidden", Boolean.FALSE, LinkOption.NOFOLLOW_LINKS);
                
		decrypt(filePath);
		
		ZipFile zipFile = new ZipFile(filePath);
		String folderToAdd = filePath.substring(0, filePath.lastIndexOf("\\")+1);
		try {
		   
		    if (zipFile.isEncrypted()) {
		        zipFile.setPassword(password);
		    }
		    zipFile.extractAll(folderToAdd);
                    
		    FileUtils.forceDelete(new File(filePath));
		    FileUtils.forceDelete(new File(filePath+".enc"));
                   
		    System.out.println("Done Decryption");
		} catch (ZipException e) {
		    System.out.println("Error in decryption decryptFile"+e);
		}
    }
    
   private  void decrypt(String filename)
    {
        /*
         * Takes filename and password as arguments and decrypts file "filename.enc" stores it as filename
         */
        try
        {
            try (FileInputStream fis = new FileInputStream(filename+".enc") // file to be decrypted
            ; FileOutputStream fos = new FileOutputStream(filename) // decrtpted file
            ) {
                byte[] keyBytes = getKey(); // get md5 hash of the password
                SecretKeySpec key = new SecretKeySpec(keyBytes,"AES"); // secret key for aes
                Cipher cipher = Cipher.getInstance("AES"); // get cipher
                cipher.init(Cipher.DECRYPT_MODE,key); // init cipher
                try (CipherInputStream cis = new CipherInputStream(fis,cipher) // get chiper input stream, to read teh file
                ) {
                    byte buf[] = new byte[1024];
                    int len;
                    while( (len = cis.read(buf,0,buf.length)) != -1) // read till end
                    {
                        fos.write(buf,0,len); // write out to encrypted file
                    }
                }
            } // decrtpted file
            // decrtpted file // decrtpted file
            // decrtpted file
                    }
        catch (IOException | InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException e) // catch all exceptions #TODO proper cleanup
        {
            System.out.println("Error in decryption decrypt"+e);
        }
    } 
    private  byte[] getKey()
	    {
	        /*
	         * Takes a string as input and returns its MD5 in byte[]
	         */
	        try
	        {
	            MessageDigest md5 = MessageDigest.getInstance("MD5"); // get the MD5 instance
	            return md5.digest(password.getBytes()); // get md5 of key ( byte[] )
	        }
	        catch(NoSuchAlgorithmException e)
	        {
	               System.out.println("Error in decryption getKey"+e);                   
	        }
	            return new byte[1];
	    }
}
