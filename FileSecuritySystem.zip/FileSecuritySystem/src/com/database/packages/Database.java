package com.database.packages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
	
	String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	String DB_URL = "jdbc:mysql://localhost:3306/";
	Connection conn = null;	
	Statement stmt = null;
	
	public Database() throws ClassNotFoundException, SQLException{
		
		Class.forName("com.mysql.jdbc.Driver");		
		conn = DriverManager.getConnection(DB_URL, "root","");
		stmt = conn.createStatement();
		String sql="CREATE DATABASE IF NOT EXISTS FSS;";
		System.out.println(executeUpdates(sql));
		sql="USE FSS;";
		System.out.println(executeUpdates(sql));
		sql="CREATE TABLE IF NOT EXISTS UserDetails(BluetoothAddress varchar(30) PRIMARY KEY,UserName varchar(50) NOT NULL,UserPassword BLOB NOT NULL,Email BLOB NOT NULL);";
		System.out.println(executeUpdates(sql));
		sql="CREATE TABLE IF NOT EXISTS UserFilePaths(BluetoothAddress varchar(30) NOT NULL,FilePaths LONGBLOB,FOREIGN KEY (BluetoothAddress) REFERENCES UserDetails(BluetoothAddress));";
		System.out.println(executeUpdates(sql));
                sql="CREATE TABLE IF NOT EXISTS UserApplicationPaths(BluetoothAddress varchar(30) NOT NULL,ApplicationPaths LONGBLOB,FOREIGN KEY (BluetoothAddress) REFERENCES UserDetails(BluetoothAddress));";
		System.out.println(executeUpdates(sql));
	}
	
	public boolean executeUpdates(String sqlQuery) throws SQLException {
		
		
		if(stmt.executeUpdate(sqlQuery) >=1)
		{
			return true;
		}
		
		return false; 
	}
	
	public ResultSet executeQuerys(String sqlQuery) throws SQLException {
            
            ResultSet rs=stmt.executeQuery(sqlQuery);
             return rs;
	}
	
	
}
