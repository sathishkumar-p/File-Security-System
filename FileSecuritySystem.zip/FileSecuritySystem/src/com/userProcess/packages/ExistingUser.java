/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.userProcess.packages;

import com.bluetooth.packages.PairedBluetoothDevices;
import com.cryptosystem.packages.ApplicationLockUnlock;
import com.cryptosystem.packages.FileDecryption;
import com.cryptosystem.packages.FileEncryption;
import com.database.packages.Database;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.bluetooth.RemoteDevice;
import net.lingala.zip4j.exception.ZipException;

/**
 *
 * @author kevin
 */
public  class ExistingUser {
    
 
  private String userDeviceAddress;
  private String userDeviceName;
 private String userName;
  private    String password;
  private   String Email;
 private Database dbObj;
 private  ArrayList<String> filePaths=new ArrayList<>();
 private  ArrayList<String> fileName=new ArrayList<>();
  private  ArrayList<String> applicationPaths=new ArrayList<>();
 private  ArrayList<String> applicationName=new ArrayList<>();
 private ArrayList<String> matchedPairedDevicAddress=new ArrayList<>();
 private ArrayList<String> matchedPairedDevicName=new ArrayList<>();
 private RemoteDevice[] pairedDevice=null;
         
    ExistingUser(String userDeviceName,String userDeviceAddress,String userName,String password,String Email,Database dbObj){
        this.userDeviceName=userDeviceName;
        this.userDeviceAddress=userDeviceAddress;
        this.userName=userName;
        this.password=password;
        this.Email=Email;
        this.dbObj=dbObj;
        initiateDecrypt();
        
    }
    
    private void initiateDecrypt(){
            
        try{
                ResultSet rs=null;
               
		String sql="SELECT FilePaths FROM UserFilePaths WHERE BluetoothAddress=\""+userDeviceAddress+"\";";
                
		  rs=dbObj.executeQuerys(sql);
                  
		  while(rs.next()) {
                      String paths=rs.getString(1).replace("/","\\");
			 filePaths.add(paths); //main object,decrypt
                         this.fileName.add(paths.substring( paths.lastIndexOf("\\")+1));
		  }
                  sql="SELECT ApplicationPaths FROM UserApplicationPaths WHERE BluetoothAddress=\""+userDeviceAddress+"\";";
                   rs=dbObj.executeQuerys(sql);
                  while(rs.next()) {
                        String paths=rs.getString(1).replace("/","\\");
			 applicationPaths.add(paths); //main object,decrypt
                         this.applicationName.add(paths.substring( paths.lastIndexOf("\\")+1));
		  }
        }
                  catch(SQLException e)
				  { 
					  System.out.println("Error in  ExistingUser initiateDecrypt()"+e);
				  }
        
    }
    public void callDecryption(ArrayList<String> path) throws ZipException, IOException{
        try{
        FileDecryption decrypt=new FileDecryption(password,path);
        }
        catch(IOException | ZipException e)
				  { 
					  System.out.println("Error in  ExistingUser callDecryption()"+e);
				  }
        
        
    }
     public void callEncryption(ArrayList<String> path) throws ZipException, IOException{
        try{
        FileEncryption decrypt=new FileEncryption(password,path);
        }
        catch(IOException | ZipException e)
				  { 
					  System.out.println("Error in  ExistingUser callEncryption()"+e);
				  }
        
        
    }
     public boolean addFile(ArrayList<String> filePath){
         
         try{ 
             
            for(String path:filePath){
               System.out.println(path);
              this.filePaths.add(path);
              path=path.replace("\\","/");
            String sql="INSERT INTO UserFilePaths VALUES(\""+userDeviceAddress+"\",\""+path+"\");";
            System.out.println(path);
             dbObj.executeUpdates(sql);
             
            }
        
                  System.out.println("File updated in databse");
                  
                 
                  callEncryption(filePath);
                  return true;
              
    
              
         }
         catch(IOException | SQLException | ZipException e){
             System.out.println("Error in  ExistingUser addFiles()"+e);
         }
         return false;
     }
      public boolean removeFile(String path){
         
         try{
             ArrayList<String> filePath= new ArrayList();
             String paths=path.replace("\\","/");
             String sql="DELETE FROM UserFilePaths WHERE FilePaths=\""+paths+"\";";
             
              if(dbObj.executeUpdates(sql)){
                  System.out.println("File removed in databse");
                  this.filePaths.remove(path);
                  filePath.add(path);
                  callDecryption(filePath);
                  return true;
              }
              else
                   System.out.println("File removed in database failed");
              
         }
         catch(IOException | SQLException | ZipException e){
             System.out.println("Error in  ExistingUser removeFiles()"+e);
              return false;
         }
         return false;
     }
     

      public boolean editProfile(String deviceName,String Username,String newPassword,String Email){
          try{
            
                
             String sql="SET FOREIGN_KEY_CHECKS=0;";
            boolean flag=false;
             if(this.matchedPairedDevicName.indexOf(deviceName)==-1){
             this.matchedPairedDevicAddress.add(this.userDeviceAddress);
             this.matchedPairedDevicName.add(this.userDeviceName);
             }
             
             String sql1="UPDATE UserDetails SET BluetoothAddress=\""+this.matchedPairedDevicAddress.get(this.matchedPairedDevicName.indexOf(deviceName))+"\",UserName=\""+Username+"\",UserPassword=\""+newPassword+"\",Email=\""+Email+"\" WHERE BluetoothAddress=\""+this.userDeviceAddress+"\";";
            String sql2="UPDATE UserFilePaths SET BluetoothAddress=\""+this.matchedPairedDevicAddress.get(this.matchedPairedDevicName.indexOf(deviceName))+"\" WHERE BluetoothAddress=\""+this.userDeviceAddress+"\";";
            String sql3="UPDATE UserApplicationPaths SET BluetoothAddress=\""+this.matchedPairedDevicAddress.get(this.matchedPairedDevicName.indexOf(deviceName))+"\" WHERE BluetoothAddress=\""+this.userDeviceAddress+"\";";
            String sql4="SET FOREIGN_KEY_CHECKS=1;";
          
            
             this.dbObj.executeQuerys(sql);
           
              this.dbObj.executeUpdates(sql1);
       
                    this.dbObj.executeUpdates(sql2);
                     
                  this.dbObj.executeUpdates(sql3);
                   
                   
                    
                     this.dbObj.executeQuerys(sql4);
                    

               
                     this.Email=Email;
                     if(!this.password.equals(newPassword)){
                         
                         if(!this.filePaths.isEmpty()){
                              this.callDecryption(this.filePaths);
                              this.password=newPassword;
                              
                              this.callEncryption(this.filePaths);
                              
                         }
                         
                      }
                     this.userName=Username;
                     System.out.println("Updation success");
                 return true;
           
         
              
           
          }
          catch(Exception e){
               System.out.println("Error in  ExistingUser editprofile()"+e);
                return false;
          }
      
      }
      
     public boolean lockApplication(String path){
        
         
          try{
            String paths=path.replace("\\","/");
             String sql="INSERT INTO UserApplicationPaths VALUES(\""+userDeviceAddress+"\",\""+paths+"\");";
             
              if(dbObj.executeUpdates(sql)){
                  System.out.println("File updated in databse");
                  this.applicationPaths.add(path);
                 
                   new ApplicationLockUnlock().Lock(path);
                  return true;
              }
              else
                   System.out.println("File updatation in databse failed");
              
         }
         catch(Exception e){
              System.out.println("Error in lock application"+e);
              return false;
          }
         return false;
     }
      
      public boolean unlockApplication(String path){
        
             try{
          
             String paths=path.replace("\\","/");
             String sql="DELETE FROM UserApplicationPaths WHERE ApplicationPaths=\""+paths+"\";";
             System.out.println(sql);
              if(dbObj.executeUpdates(sql)){
                  System.out.println("File removed in databse");
                  this.applicationPaths.remove(path);
                   new ApplicationLockUnlock().unLock(path);
                  return true;
              }
              else
                   System.out.println("File removed in database failed");
              
         }
         catch(Exception e){
              System.out.println("Error in unlock application"+e);
              return false;
          }
         return false;
         
     }
      
      
    public String getUserDeviceAddress() {
        return userDeviceAddress;
    }

    public String getUserDeviceName() {
        return userDeviceName;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return Email;
    }

    public ArrayList<String> getFileName() {
        return fileName;
    }

   

    public ArrayList<String> getMatchedPairedDevicName() {
        
        try{
        pairedDevice=new PairedBluetoothDevices().getPairedBluetoothDevice();
        ResultSet rs;
        for(RemoteDevice remo:this.pairedDevice){
           String sql="SELECT BluetoothAddress FROM UserDetails WHERE BluetoothAddress=\""+remo.getBluetoothAddress()+"\";";
            rs=this.dbObj.executeQuerys(sql);
            if(!rs.next())
            {
            this.matchedPairedDevicAddress.add(remo.getBluetoothAddress().toString());
            this.matchedPairedDevicName.add(remo.getFriendlyName(false).toString());
            }
        }
       }
        catch(Exception e){
            System.out.println("Error in ExisitingUser  getMatchedPairedDevicName"+e);
        }
        return matchedPairedDevicName;
    }

    public ArrayList<String> getFilePaths() {
        return filePaths;
    }

    public ArrayList<String> getApplicationPaths() {
        return applicationPaths;
    }

    public ArrayList<String> getApplicationName() {
        return applicationName;
    }
    
        
}
