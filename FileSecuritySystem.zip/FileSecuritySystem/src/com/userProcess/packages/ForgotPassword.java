/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.userProcess.packages;

/**
 *
 * @author kevin
 */


import com.cryptosystem.packages.FileDecryption;
import com.cryptosystem.packages.FileEncryption;
import com.database.packages.Database;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class ForgotPassword {
Database dbObj;
ArrayList<String> userConnectedDeviceAddress;
String userDevice;
String Email;
String UserName=null;
String Password=null;
int screteCode;
Scanner sc=new Scanner(System.in);

public ForgotPassword(ArrayList<String>userConnectedDeviceAddress, Database dbObj){
    this.userConnectedDeviceAddress=userConnectedDeviceAddress;
    this.dbObj=dbObj;
    
}


public boolean emailValidate(String Email){

    ResultSet rs;
    String sql;
   
   /* System.out.println("Enter the Mail");
    this.Email=sc.nextLine();*/
   this.Email=Email;
    try{
     for(String add:userConnectedDeviceAddress) {
         
	sql="SELECT UserName,UserPassword,Email from UserDetails where BluetoothAddress=\""+add+"\";";
	rs=dbObj.executeQuerys(sql);
        
	if(rs.next()&&rs.getString(3).equals(this.Email)) {
	System.out.println("Email Validation success");
        this.Password=rs.getString(2);
        this.UserName=rs.getString(1);
        this.userDevice=add;
        this.emailCodeSend();
        System.out.println("Code send to email");
        return true;
        }
        }
     if(this.Password==null)
     {
         System.out.println("Enter the correct Email");
        return false;
     }
    }
    catch(Exception e){
        System.out.println("Error in ForgotPassword emailvalidate()"+e);
         return false;
    }
    return false;
}

public boolean emailCodeSend(){
    
    try{
            this.screteCode=new Random().nextInt(9999-1000)+1000;
            EmailService emailSer=new EmailService(this.screteCode,this.Email,this.UserName);
            
            return true;
   
    }
    catch(Exception e)
    {
        System.out.println("Error in Forgotpassword emailCodeSend()");
         return false;
    }
    
}
public boolean screteCodeValidate(int code){
    
    try{
          
           /*  System.out.println("Enter the Code");*/
             if(this.screteCode==code){
             System.out.println("code Verified success");
            
             return true;
             }
             else{
                System.out.println("code Verified failed");
                
             return false;
             }
                 
   
    }
    catch(Exception e)
    {
        System.out.println("Error in Forgotpassword screteCodeValidate()" + e);
         return false;
    }
    
}

public boolean passwordRestting(String Password){
       
    try{
           ResultSet rs;
           ArrayList<String> filePaths=new ArrayList<>();
           String sql="SELECT FilePaths FROM UserFilePaths WHERE BluetoothAddress=\""+this.userDevice+"\";";
           rs=this.dbObj.executeQuerys(sql);
           while(rs.next())
           {
              filePaths.add(rs.getString(1));
           }
         
                   if(!this.Password.equals(Password)){
                         
                         if(!filePaths.isEmpty()){
                               new FileDecryption(this.Password,filePaths);
                               this.Password=Password;
                              
                                   new FileEncryption(this.Password,filePaths);
                              
                         }
                         
                      }
           
           sql="UPDATE UserDetails SET UserPassword=\""+this.Password+"\"WHERE BluetoothAddress=\""+this.userDevice+"\";";
           this.dbObj.executeUpdates(sql);
           System.out.println("Password Changed success");
        
           return true;
          
           
       }
       catch(Exception e){
           System.out.println("Error in Forgotpassword passwordRestting()" + e);
            return false;
       }
   
   
}
 public boolean netIsAvailable() {
    try {
        final URL url = new URL("http://www.google.com");
        final URLConnection conn = url.openConnection();
        conn.connect();
        return true;
    } catch (MalformedURLException e) {
        throw new RuntimeException(e);
    } catch (IOException e) 
    {
        return false;
    }
    }

}
