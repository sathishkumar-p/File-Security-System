/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.userProcess.packages;

import static com.sun.javafx.animation.TickCalculation.sub;
import static java.lang.ProcessBuilder.Redirect.to;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author kevin
 */
public class EmailService {

  
   public EmailService(int screteCode,String toEmail,String Username) {
          Properties props = new Properties();    
          props.put("mail.smtp.host", "smtp.gmail.com");    
          props.put("mail.smtp.socketFactory.port", "465");    
          props.put("mail.smtp.socketFactory.class",    
                    "javax.net.ssl.SSLSocketFactory");    
          props.put("mail.smtp.auth", "true");    
          props.put("mail.smtp.port", "465");    
          //get Session   
          Session session = Session.getDefaultInstance(props,    
           new javax.mail.Authenticator() {    
           @Override
           protected PasswordAuthentication getPasswordAuthentication() {    
           return new PasswordAuthentication("temporarymailid270@gmail.com","Temp@2018");  
           }    
          });    
           try {    
           MimeMessage message = new MimeMessage(session);    
           message.addRecipient(Message.RecipientType.TO,new InternetAddress(toEmail));    
           message.setSubject("Password Resetting");    
           message.setContent("<h1>UserName : </h1><h3>"+Username+"</h3><br/><h1>Screte Code : </h1><h3>"+screteCode+"</h3>", "text/html");
           //send message  
           Transport.send(message);    
           System.out.println("message sent successfully");    
          
          } catch (MessagingException e) {throw new RuntimeException(e);}   
    
    }
    
}
