package com.userProcess.packages;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;

import com.database.packages.Database;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class UserValidate {

	 ArrayList<String> userConnectedDeviceAddress;
	 ArrayList<String> userConnectedDeviceName;
	 ArrayList<String> userName;
	 ArrayList<String> userPassword;
	 Database dbObj;
	 ExistingUser exitUsr;
         ForgotPassword FP;

   
	 
	public UserValidate(ArrayList<String> userConnectedDeviceName,ArrayList<String> userConnectedDeviceAddress,Database dbObj) {
		
		this.userConnectedDeviceAddress=userConnectedDeviceAddress;
		this.userConnectedDeviceName=userConnectedDeviceName;
		this.dbObj=dbObj;
		
		
	}
	public boolean validate(String username,String password) {
		
		try {
			ResultSet rs=null;
                        int index=0;
                        String address=null,emailid=null;
                        boolean isValidate=true;
			String sql=null;
                        Scanner sc=new Scanner(System.in);
			/*System.out.println("Enter User name and password");
			
			username=sc.nextLine();
			password=sc.nextLine();*/
                        if(username.equals("forgot")&&password.equals("forgot"))//checking internet and returns false if not connected
                        {
                          
                            
                            FP=new ForgotPassword(this.userConnectedDeviceAddress,this.dbObj);    
                            return true;
                            
                            
                        }
                        else{
			
			for(String add:userConnectedDeviceAddress) {
					sql="SELECT UserName,UserPassword, Email from UserDetails where BluetoothAddress=\""+add+"\";";
					System.out.println(sql);
                                        rs=dbObj.executeQuerys(sql);
					if(rs.next()&&rs.getString(1).equals(username)&&rs.getString(2).equals(password)) {
                                         System.out.println("Validation success");
                                         isValidate=false;
                                           address=add;
                                          emailid=rs.getString(3);
                                          break;		       
								  
							
					  }
                                        index++;
                                       }       
                        if(isValidate){
                            System.out.println("Enter the correct /username password");
                            return false;
                        }
                        else{
                            System.out.println(userConnectedDeviceName.get(index));
                         exitUsr=new ExistingUser(userConnectedDeviceName.get(index),address,username,password,emailid,dbObj);
                         return true;
                        }
                        
                        }
                        
		}
				catch(Exception e)
				  { 
					  System.out.println("Error in UserValidate validate()"+e);
                                           return false;
				  }
		
		
	}
        public boolean netIsAvailable() {
    try {
        final URL url = new URL("http://www.google.com");
        final URLConnection conn = url.openConnection();
        conn.connect();
        return true;
    } catch (MalformedURLException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        return false;
    }
    }
        public ExistingUser getExisitingUserObject(){
            
            return exitUsr;
        }
         public ForgotPassword getFP() {
        return FP;
    }
}
