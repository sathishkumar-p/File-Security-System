/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.userProcess.packages;
import com.bluetooth.packages.PairedBluetoothDevices;
import com.database.packages.Database;
import filesecuritysystem.FileSecuritySystem;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.bluetooth.RemoteDevice;
/**
 *
 * @author kevin
 */
public class NewUser {
    
    private RemoteDevice[] pairedDevice;
    private ArrayList<String> matchedPairedDevicAddress=new ArrayList<String>();
    private ArrayList<String> matchedPairedDevicName=new ArrayList<String>();
    private Database dbObj;
    String sql=null;
    
    public NewUser(Database dbObj) {//check bluetooth powered on
        try{
        pairedDevice=new PairedBluetoothDevices().getPairedBluetoothDevice();
        this.dbObj=FileSecuritySystem.dbObj;
        this.devices();
       }
        catch(Exception e){
            System.out.println("Error in New User constructor "+e);
        }
        
    }
    
   public void devices(){
        try{
        
             ResultSet rs;
        for(RemoteDevice remo:this.pairedDevice){
         
            sql="SELECT BluetoothAddress FROM UserDetails WHERE BluetoothAddress=\""+remo.getBluetoothAddress()+"\";";
                
            
           rs= this.dbObj.executeQuerys(sql);
            
            if(!rs.next())
            {
            this.matchedPairedDevicAddress.add(remo.getBluetoothAddress());
            this.matchedPairedDevicName.add(remo.getFriendlyName(false));
            }
        }
        }
        catch(Exception e){
            System.out.println("Error in New User devices()"+e);
          }
       
    }
    
    public boolean addUser(String deviceName,String UserName,String Password,String Email){
        
            try{
                
                sql="INSERT INTO UserDetails VALUES('"+this.matchedPairedDevicAddress.get(this.matchedPairedDevicName.indexOf(deviceName))+"','"+UserName+"','"+Password+"','"+Email+"');";
                this.dbObj.executeUpdates(sql);
                System.out.println("New user added");
               
                return true;
            }
            catch(Exception e){
                System.out.println("Error in new user add User"+e);
                return false;
            }
        
    }
    
    
     public boolean isLocalDevicePowerOn(){
     return javax.bluetooth.LocalDevice.isPowerOn();
 }

    public ArrayList<String> getMatchedPairedDevicAddress() {
        return matchedPairedDevicAddress;
    }

    public ArrayList<String> getMatchedPairedDevicName() {
        return matchedPairedDevicName;
    }
    
}
