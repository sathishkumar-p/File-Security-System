package com.bluetooth.packages;

import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.LocalDevice;
import java.io.IOException;
import javax.bluetooth.RemoteDevice;

public class PairedBluetoothDevices {

	public RemoteDevice[] getPairedBluetoothDevice() throws IOException {
		
		
		LocalDevice localDevice = LocalDevice.getLocalDevice();
                
                RemoteDevice[] remotedevice=localDevice.getDiscoveryAgent().retrieveDevices(DiscoveryAgent.PREKNOWN);
		
		 return remotedevice;

	}

}
