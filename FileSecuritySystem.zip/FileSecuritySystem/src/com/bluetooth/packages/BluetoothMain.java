package com.bluetooth.packages;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


import com.database.packages.Database;
import com.userProcess.packages.ExistingUser;
import com.userProcess.packages.UserValidate;
import java.sql.SQLException;



public class BluetoothMain {

 ArrayList < String > userConnectedDeviceAddress;
 ArrayList < String > userConnectedDeviceName;
 ArrayList < String > usersAllBluetoothAddress;
 Database dbOBj;
 UserValidate usrVali;

 public BluetoothMain(Database dbOBj) {
  try {

   userConnectedDeviceAddress = new ArrayList < > ();
   userConnectedDeviceName = new ArrayList < > ();
   usersAllBluetoothAddress = new ArrayList < > ();
   String sql = "select BluetoothAddress from UserDetails";
   ResultSet rs = null;
   this.dbOBj = dbOBj;

   rs = dbOBj.executeQuerys(sql);
   
   while (rs.next()) {
    usersAllBluetoothAddress.add(rs.getString(1));
   }

 

  } catch (SQLException e) {
   System.out.println("Error in Bluetooth Main Constructor" + e);
  }

 }
 
 public boolean isLocalDevicePowerOn(){
     return javax.bluetooth.LocalDevice.isPowerOn();
 }
 
 public boolean searchBluetoothDevice() {

  try {

   Map < String, List < String >> mapReturnResult = new HashMap < > ();
   boolean flag;
   ServicesSearch ss = new ServicesSearch();
   mapReturnResult = ss.getBluetoothDevices();

   for (Map.Entry < String, List < String >> entry: mapReturnResult.entrySet()) {

    flag = false;

    for (String d: usersAllBluetoothAddress) {
     if (d.equals(entry.getValue().get(1))) {
      flag = true;
      break;
     }
    }

    if (flag) {

     if (entry.getValue().size() > 2 && entry.getValue().get(2) != null) {

      userConnectedDeviceName.add(entry.getValue().get(0));
      userConnectedDeviceAddress.add(entry.getValue().get(1));
      System.out.println("Connected" + userConnectedDeviceName);

     }

    }
   }

   if (!userConnectedDeviceName.isEmpty()) {
    usrVali = new UserValidate(userConnectedDeviceName, userConnectedDeviceAddress, dbOBj);
    return true;
   } else {

    System.out.println("No device connected");
    return false;

   }
  } catch (Exception e) {
   System.out.println("Error in Bluetooth Main searchBluetoothDevice" + e);
   return false;
  }
  
 }


 public void asyncBluetoothCheck(String connectedDeviceAddress) {
  try {



     for (int k = 0; k == 0;) {

      ServicesSearch ss = new ServicesSearch();
      Map < String, List < String >> mapReturnResult = new HashMap < String, List < String >> ();
      mapReturnResult = ss.getBluetoothDevices();

      for (Map.Entry < String, List < String >> entry: mapReturnResult.entrySet()) {

       if (connectedDeviceAddress.equals(entry.getValue().get(1).toString())) {
        if (entry.getValue().size() > 2 && entry.getValue().get(2) != null) {

         System.out.println("Connected");

        } else {

         k = 2;
         System.out.println("Device disconnected");//error close the application
            
        }
       }


      }

     }
    
 
  } catch (Exception e) {
   System.out.println("Error in Bluetooth Main asyncBluetoothCheck" + e);
  
  }
 }
 public UserValidate getUserValidate() {

  return usrVali;
 }
}