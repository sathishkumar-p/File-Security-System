/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bluetooth.packages;

import com.database.packages.Database;
import com.userProcess.packages.EmailService;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import javax.bluetooth.RemoteDevice;

/**
 *
 * @author kevin
 */
public class DeviceLost {
    private int screteCode;
    private ArrayList<String> matchedPairedDevicAddress=null;
    private ArrayList<String> matchedPairedDevicName=null;
    private RemoteDevice[] pairedDevice=null;
    private String UserName=null;
    private String Password=null;
    private String Email=null;
    private Database dbObj=null;
    private String lostDeviceName=null;
    Scanner sc=new Scanner(System.in);
    String sql;
    
    public DeviceLost(Database dbObj){//after creation of object check internet by calling function
       
        this.dbObj=dbObj;
             
    }
    
      public boolean netIsAvailable() {
    try {
        final URL url = new URL("http://www.google.com");
        final URLConnection conn = url.openConnection();
        conn.connect();
        return true;
    } catch (MalformedURLException e) {
        throw new RuntimeException(e);
    } catch (IOException e) {
        return false;
    }
    }
    public boolean verifyUser(String username,String password,String Email){
        
        try{
            ResultSet rs=null;
        sql="SELECT BluetoothAddress FROM UserDetails WHERE UserName=\""+username+"\" AND UserPassword=\""+password+"\" AND Email=\""+Email+"\"; ";
        rs=this.dbObj.executeQuerys(sql);
        if(rs.next()){
            System.out.println("User Verifed ");
            this.lostDeviceName=rs.getString(1);
            this.Email=Email;
            this.Password=password;
            this.UserName=username;
            this.screteCode=new Random().nextInt(9999-1000)+1000;
            EmailService emailSer=new EmailService(this.screteCode,this.Email,this.UserName);
            return true;
        }
        }
        catch(Exception e){
            System.out.println("Error in DeviceLost verifyUser() " + e);
             return false;
          }
        
        return false;
    }
     public boolean verifyCode(int code){
            try{
                if(this.screteCode==code)
                return true;
            }
            catch(Exception e){
                System.out.println("Error in DeviceLost verifyCode() " + e);
                 return false;
            }
            return false;
     }
     
  public ArrayList<String> getMatchedPairedDevicName() {
        
        try{
        pairedDevice=new PairedBluetoothDevices().getPairedBluetoothDevice();
        ResultSet rs;
        for(RemoteDevice remo:this.pairedDevice){
           String sql="SELECT BluetoothAddress FROM UserDetails WHERE BluetoothAddress=\""+remo.getBluetoothAddress()+"\";";
            rs=this.dbObj.executeQuerys(sql);
            if(!rs.next())
            {
            this.matchedPairedDevicAddress.add(remo.getBluetoothAddress());
            this.matchedPairedDevicName.add(remo.getFriendlyName(false));
            }
        }
       }
        catch(Exception e){
            System.out.println("Error in device lost  getMatchedPairedDevicName"+e);
            
        }
        return matchedPairedDevicName;
    }
    
     
     public boolean changeDevice(String deviceName){
         
         try{
             sql="SET FOREIGN_KEY_CHECKS=0;";
              String sql1="UPDATE UserDetails SET BluetoothAddress=\""+this.matchedPairedDevicAddress.get(this.matchedPairedDevicName.indexOf(deviceName))+"\" WHERE BluetoothAddress=\""+this.lostDeviceName+"\";";
            String sql2="UPDATE UserFilePaths SET BluetoothAddress=\""+this.matchedPairedDevicAddress.get(this.matchedPairedDevicName.indexOf(deviceName))+"\" WHERE BluetoothAddress=\""+this.lostDeviceName+"\";";
            String sql3="UPDATE UserApplicationPaths SET BluetoothAddress=\""+this.matchedPairedDevicAddress.get(this.matchedPairedDevicName.indexOf(deviceName))+"\" WHERE BluetoothAddress=\""+this.lostDeviceName+"\";";
            String sql4="SET FOREIGN_KEY_CHECKS=1;";
          
            
             this.dbObj.executeQuerys(sql);
     
                    this.dbObj.executeUpdates(sql1);
                    this.dbObj.executeUpdates(sql2);
                     
                  this.dbObj.executeUpdates(sql3);
                               
                    
                     this.dbObj.executeQuerys(sql4);
           
                System.out.println("Device changed");
                
                return true;
    
         }
         catch(Exception e){
            System.out.println("Error in DeviceLost changeDevice"+e);
             return false;
        }
             
     }
    
}
